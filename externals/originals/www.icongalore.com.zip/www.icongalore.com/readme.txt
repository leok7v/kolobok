Visit:

http://www.icongalore.com


Hundreds of professional XP style icons that come with highly professional design for use in your GUI and web based applications. Each icon is available in four different sizes that includes 16x16, 24x24, 32x32 and 48x48. Each icon has been provided in two different color depths and three formats that include .ico, png and gif. We also offer Vector icons on request. Main Features: Professionally designed using microsoft xp style icon creation guidelines, hundreds of icons classified in to categories like navigation, web, network, ecommerce, email, icon concepts and more. Priced extremely low and offers the best quality available on the net. For complete icon package set visit icongalore.com

Please Send your quarries to support@icongalore.com


Regards
George Support Manager at icongalore.com
